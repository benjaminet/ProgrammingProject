function User(email, password){
    this.email = email;
    this.password = password;
}