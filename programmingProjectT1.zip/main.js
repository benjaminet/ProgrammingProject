function generateAndShowRentalHtmlOverview(rental) {
    $("#content").append(`
    <div class="col-lg-3 item" onclick="rentalClicked('${allRentals.indexOf(rental)}')">
    <img src='${rental.imageUrl}' />
        <p class='location'>${rental.type} &bull; ${rental.city}, ${rental.country}</p>
        <p class='title'>${rental.title}</p>
        <p class='price'>${rental.price} GBP per night</p>
        <p class='guests'>${rental.guests} guests</p>
    </div>
    `)
}

function generateAndShowRentalHtmlDetailed(rental) {
    $("#content").append(`                                   
    <div class="col-lg-12">
        <button type="button" class="btn btn-info" onclick="filterRentals()">Back</button>
    </div> 
    <div class="col-lg-6 item">
    <img src='${rental.imageUrl}' />
    </div>                                            
    <div class="col-lg-5 item">
        <p class='location'>${rental.type} &bull; ${rental.city}, ${rental.country}</p>
        <p class='title'>${rental.title}</p>
        <p class='price'>${rental.price} GBP per night</p>
        <p class='guests'>${rental.guests} guests</p>
        <p class='rooms'>${rental.rooms} rooms</p>
        <p class='smoking'>Smoking? ${rental.smoking}</p>
        <p class='wifi'>Wifi? ${rental.hasWifi}</p>
        <p class='laundry'>Laundry? ${rental.hasLaundry}</p>
        <p class='tv'>TV? ${rental.hasTV}</p>
        <p class='aircon'>Aircondition? ${rental.hasAircon}</p>
        <p>Start Date</p><input style="width: 30%;" type="date" class="form-control" id="startdate" placeholder="Start Date">
        <p>End Date</p><input style="width: 30%;" type="date" class="form-control" id="enddate" placeholder="End Date">
    </div>
    <div>
        <button type="button" class="btn btn-success" onclick="bookRental('${allRentals.indexOf(rental)}')">Book</button>
    </div>
    `)
}

function rentalClicked(rentalIndex) {
    $("#content").html("");
    var rental = allRentals[rentalIndex];
    generateAndShowRentalHtmlDetailed(rental);
}

function bookRental(rentalIndex) {
    var clickedRental = allRentals[rentalIndex];
    var startDate = $("#startdate").val();
    var endDate = $("#enddate").val();
    var newBooking = new Booking(clickedRental, startDate, endDate);

    for (let booking of bookings) {
        if (booking.rental === clickedRental) {
            return;
        }
    }

    bookings.push(newBooking);
    localStorage.setItem("bookings", JSON.stringify(bookings));
    renderBookings();
}

function removeBooking(bookingIndex) {
    var rental = bookings[bookingIndex];
    bookings.splice(bookingIndex, 1);
    localStorage.setItem("bookings", JSON.stringify(bookings));
    renderBookings();
}

function renderBookings() {
    var bookingList = $("#booking-list");
    bookingList.html("");
    for (let booking of bookings) {
        bookingList.append(`<li  class="list-group-item d-flex justify-content-between align-items-center">
            ${booking.rental.title} (${booking.startDate} to ${booking.endDate})
            <span class="badge badge-primary badge-pill">$${booking.rental.price}</span>
            <span class="badge badge-danger badge-pill" style="cursor:pointer;" onclick="removeBooking('${bookings.indexOf(booking)}')">Remove</span>
            </li>`);
    }
}


function filterRentals(country, rentalType, price, guests) {
    var filteredRentals = allRentals;

    if (country !== undefined && country != "Default") {
        filteredRentals = filteredRentals.filter(rental => rental.country === country);
    }

    if (rentalType !== undefined && rentalType != "Default") {
        filteredRentals = filteredRentals.filter(rental => rental.type === rentalType);
    }

    if (price !== undefined && price !== "") {
        filteredRentals = filteredRentals.filter(rental => rental.price <= price);
    }

    if (guests !== undefined && guests !== "") {
        filteredRentals = filteredRentals.filter(rental => rental.guests >= guests);
    }

    $("#content").html("");

    for (var rental of filteredRentals) {
        generateAndShowRentalHtmlOverview(rental);
    }
}

function filterChanged() {
    var country = $("#destinationDdl").val();
    var rentalType = $("#rentalTypesDdl").val();
    var price = $("#max-price-input").val();
    var guests = $("#no_of_guests").val();

    filterRentals(country, rentalType, price, guests);
}

$(document).ready(function () {
    for (var rental of allRentals) {
        generateAndShowRentalHtmlOverview(rental);
    }
});
