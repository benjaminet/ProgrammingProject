function forgotPassword() {
    window.location = "newPassword.html";
}

function register() {
    window.location = "register.html";
}

function login() {
    var email = document.getElementById("email").value;
    var pwd = document.getElementById("pwd").value;

    if (email == '') {
        alert("Please enter your email.");
    }
    else if (pwd == '') {
        alert("Please enter the password.");
    }
    
    else {
        var storedEmail = localStorage.getItem("email");
        var storedPwd = localStorage.getItem("pwd");
        if (email == storedEmail && pwd == storedPwd) {
            window.location = "mainPage.html";
        }
    }

    return false;
}