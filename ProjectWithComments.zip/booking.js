// becomes a booking object when a booking is created
function Booking(rental, startDate, endDate){
    this.rental = rental;
    this.startDate = startDate;
    this.endDate = endDate;
}