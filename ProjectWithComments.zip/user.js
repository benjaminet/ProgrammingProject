// happens when a new user is registered
function User(email, password){
    this.email = email;
    this.password = password;
}